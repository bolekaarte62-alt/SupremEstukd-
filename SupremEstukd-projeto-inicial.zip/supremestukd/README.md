# SupremEstukd

Plataforma de estudos em Next.js com módulo Suprem AI, geração de provas e painel de pontos.

## Requisitos
- Node.js 20 ou superior
- Uma chave da OpenAI API (a API é cobrada separadamente do ChatGPT)

## Rodar no computador
1. Extraia o ZIP.
2. Abra a pasta no terminal.
3. Execute `npm install`.
4. Copie `.env.example` para `.env.local`.
5. Coloque sua chave em `OPENAI_API_KEY` no arquivo `.env.local`.
6. Execute `npm run dev`.
7. Abra `http://localhost:3000`.

Nunca coloque a chave da API em arquivos públicos, no navegador ou em repositórios.

## Publicar
1. Envie este projeto para um repositório privado no GitHub.
2. Importe o repositório na Vercel.
3. Em Settings > Environment Variables, adicione `OPENAI_API_KEY` e, opcionalmente, `OPENAI_MODEL`.
4. Faça o deploy. A Vercel fornecerá um endereço público.

## Observações da primeira versão
- O chat e o gerador de provas usam a rota de servidor `/api/ai`.
- Os pontos e o histórico ficam apenas na memória da página nesta versão.
- Login, banco de dados compartilhado, recuperação de senha, proteção contra abuso e painel administrativo ainda precisam ser implementados antes de abrir o site ao público.
- Configure limites e alertas de gastos na plataforma da API.
