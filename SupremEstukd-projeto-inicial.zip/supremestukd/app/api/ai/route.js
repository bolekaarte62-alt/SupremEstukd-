import OpenAI from "openai";
import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function POST(request) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "A chave da OpenAI ainda não foi configurada no servidor." }, { status: 503 });
    }
    const { mode, prompt, subject, level } = await request.json();
    if (!prompt || typeof prompt !== "string" || prompt.length > 5000) {
      return NextResponse.json({ error: "Envie uma pergunta válida (até 5.000 caracteres)." }, { status: 400 });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const instructions = mode === "quiz"
      ? `Você é o criador de provas do SupremEstukd. Crie exatamente 5 questões de múltipla escolha em português sobre ${subject}, para o nível: ${level}. Responda SOMENTE com JSON válido neste formato: {"title":"Prova de ${subject}","questions":[{"question":"...","options":["A) ...","B) ...","C) ...","D) ..."],"answer":0}] . O campo answer deve ser o índice correto entre 0 e 3. Não inclua gabarito no texto das questões.`
      : `Você é o Suprem AI, professor paciente e claro da plataforma SupremEstukd. Ajude com ${subject}. Nível do estudante: ${level}. Explique em português simples, passo a passo, com exemplos adequados. Se a pergunta estiver ambígua, peça esclarecimento.`;

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions,
      input: prompt
    });

    const answer = response.output_text || "";
    if (mode === "quiz") {
      const cleaned = answer.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
      const quiz = JSON.parse(cleaned);
      if (!Array.isArray(quiz.questions) || quiz.questions.length !== 5) throw new Error("Formato de prova inválido.");
      return NextResponse.json({ quiz });
    }
    return NextResponse.json({ answer });
  } catch (error) {
    console.error("Suprem AI error:", error);
    return NextResponse.json({ error: "Ocorreu um erro ao gerar a resposta. Tente novamente." }, { status: 500 });
  }
}
