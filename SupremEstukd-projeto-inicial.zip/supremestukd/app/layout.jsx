import "./globals.css";

export const metadata = {
  title: "SupremEstukd | Seu espaço de estudos",
  description: "Estude, pratique e evolua com o SupremEstukd e o Suprem AI."
};

export default function RootLayout({ children }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
