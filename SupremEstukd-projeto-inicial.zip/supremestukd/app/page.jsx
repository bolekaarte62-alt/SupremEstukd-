"use client";

import { useState } from "react";

const subjects = ["Matemática", "Português", "História", "Geografia", "Ciências", "Inglês"];
const summaries = {
  "Matemática": "A matemática estuda números, operações, formas e padrões. As quatro operações básicas são adição, subtração, multiplicação e divisão.",
  "Português": "A língua portuguesa permite comunicar ideias. Substantivos dão nome a seres e coisas; verbos indicam ações, estados ou fenômenos.",
  "História": "A História estuda as ações humanas ao longo do tempo. A Independência do Brasil foi proclamada em 7 de setembro de 1822.",
  "Geografia": "A Geografia estuda o espaço geográfico, os lugares, as paisagens e a relação entre sociedade e natureza.",
  "Ciências": "As Ciências investigam a natureza e os seres vivos. A água é essencial à vida e o corpo humano possui sistemas que trabalham juntos.",
  "Inglês": "O inglês é falado em vários países. Hello significa olá, book significa livro, school significa escola e water significa água."
};

export default function Home() {
  const [tab, setTab] = useState("inicio");
  const [subject, setSubject] = useState("Matemática");
  const [question, setQuestion] = useState("");
  const [level, setLevel] = useState("Adaptável ao meu nível escolar");
  const [messages, setMessages] = useState([{ role: "assistant", content: "Olá! Eu sou o Suprem AI. Qual matéria você quer aprender hoje?" }]);
  const [busy, setBusy] = useState(false);
  const [points, setPoints] = useState(0);
  const [done, setDone] = useState(0);
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [grade, setGrade] = useState(null);

  async function askAI(mode) {
    const prompt = question.trim();
    if (!prompt || busy) return;
    setMessages(m => [...m, { role: "user", content: prompt }]);
    setQuestion("");
    setBusy(true);
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode, prompt, subject, level })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Não foi possível falar com a IA.");
      setMessages(m => [...m, { role: "assistant", content: data.answer }]);
    } catch (e) {
      setMessages(m => [...m, { role: "assistant", content: "Não consegui conectar agora: " + e.message + " Confira se a chave da API foi configurada no servidor." }]);
    } finally {
      setBusy(false);
    }
  }

  async function createQuiz() {
    setBusy(true); setQuiz(null); setGrade(null); setAnswers({});
    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "quiz", prompt: `Crie uma prova com 5 questões de múltipla escolha sobre ${subject}.`, subject, level })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erro ao criar prova.");
      setQuiz(data.quiz);
    } catch (e) {
      alert("Não foi possível criar a prova: " + e.message);
    } finally { setBusy(false); }
  }

  function finishQuiz() {
    if (!quiz) return;
    const score = quiz.questions.reduce((n, q, i) => n + (Number(answers[i]) === q.answer ? 1 : 0), 0);
    setGrade({ score, total: quiz.questions.length });
    setDone(v => v + quiz.questions.length);
    setPoints(v => v + score * 10);
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-icon">✦</span><span>Suprem<span className="blue">Estukd</span></span></div>
        <div className="side-label">MENU PRINCIPAL</div>
        {[["inicio","⌂","Início"],["materias","▤","Matérias e resumos"],["provas","✓","Provas e exercícios"],["ia","✧","Suprem AI"]].map(([id,icon,label]) =>
          <button key={id} className={`nav ${tab===id?"active":""}`} onClick={()=>setTab(id)}><span>{icon}</span>{label}</button>
        )}
        <div className="sidebar-bottom"><div className="mini-avatar">S</div><div><b>Estudante</b><small>Continue evoluindo!</small></div></div>
      </aside>

      <section className="main">
        <header className="topbar"><div><span className="muted">PLATAFORMA DE APRENDIZADO</span><h1>{tab==="inicio"?"Seu espaço de evolução":tab==="materias"?"Matérias e resumos":tab==="provas"?"Provas e exercícios":"Suprem AI"}</h1></div><div className="online">● Sistema de estudos</div></header>

        {tab==="inicio" && <>
          <section className="hero"><div className="hero-copy"><span className="eyebrow">BEM-VINDO AO SUPREMESTUKD</span><h2>Seu conhecimento<br/>é seu maior poder.</h2><p>Aprenda no seu ritmo, pratique e acompanhe sua evolução.</p><button className="primary light" onClick={()=>setTab("materias")}>Começar a estudar <span>→</span></button></div><div className="hero-art">✦<div className="orbit">✧</div></div></section>
          <div className="stats"><Stat icon="⭐" label="Pontos conquistados" value={points}/><Stat icon="📝" label="Questões respondidas" value={done}/><Stat icon="🏆" label="Nível atual" value={1+Math.floor(points/100)}/></div>
          <section className="section"><div className="section-head"><div><span className="muted">SEU APRENDIZADO</span><h2>Continue estudando</h2></div><button className="text-button" onClick={()=>setTab("materias")}>Ver matérias →</button></div><div className="subject-grid">{subjects.slice(0,4).map((s,i)=><SubjectCard key={s} name={s} icon={["📐","✍️","🏛️","🌎"][i]} onClick={()=>{setSubject(s);setTab("materias")}}/>)}</div></section>
          <section className="ai-banner"><div><span className="eyebrow">SEU PROFESSOR PARTICULAR</span><h2>Conheça o Suprem AI</h2><p>Tire dúvidas, peça explicações e crie provas personalizadas.</p><button className="primary" onClick={()=>setTab("ia")}>Conversar com a IA →</button></div><div className="ai-symbol">✧</div></section>
        </>}

        {tab==="materias" && <section className="section"><p className="muted">Escolha uma matéria para ver seu resumo.</p><div className="subject-grid">{subjects.map((s,i)=><SubjectCard key={s} name={s} icon={["📐","✍️","🏛️","🌎","🔬","🌐"][i]} onClick={()=>setSubject(s)}/>)}</div><article className="content-card"><span className="eyebrow">RESUMO DE ESTUDO</span><h2>{subject}</h2><p>{summaries[subject]}</p><button className="primary" onClick={()=>setTab("provas")}>Praticar esta matéria →</button></article></section>}

        {tab==="provas" && <section className="section"><div className="content-card"><span className="eyebrow">AVALIAÇÃO PERSONALIZADA</span><h2>Monte sua prova</h2><p>Escolha a matéria e deixe o Suprem AI preparar questões adequadas ao seu nível.</p><label>Matéria<select value={subject} onChange={e=>setSubject(e.target.value)}>{subjects.map(s=><option key={s}>{s}</option>)}</select></label><label>Nível<select value={level} onChange={e=>setLevel(e.target.value)}><option>Adaptável ao meu nível escolar</option><option>Fácil</option><option>Médio</option><option>Difícil</option><option>Avançado, estilo vestibular</option></select></label><button className="primary" disabled={busy} onClick={createQuiz}>{busy?"Criando prova...":"✦ Gerar prova com IA"}</button></div>
          {quiz && <div className="content-card"><span className="eyebrow">SUA PROVA</span><h2>{quiz.title || subject}</h2>{quiz.questions.map((q,i)=><div className="question" key={i}><b>{i+1}. {q.question}</b>{q.options.map((o,j)=><label className="option" key={j}><input type="radio" name={`q${i}`} checked={String(answers[i])===String(j)} onChange={()=>setAnswers(a=>({...a,[i]:j}))}/>{o}</label>)}</div>)}{grade?<div className="result">Você acertou {grade.score} de {grade.total} questões e ganhou {grade.score*10} pontos!</div>:<button className="primary" onClick={finishQuiz} disabled={Object.keys(answers).length!==quiz.questions.length}>Corrigir minha prova</button>}</div>}
        </section>}

        {tab==="ia" && <section className="chat-card"><div className="chat-head"><div className="bot-icon">✧</div><div><b>Suprem AI</b><small>Seu professor inteligente</small></div><span className="online">● Pronto para ajudar</span></div><div className="chat-messages">{messages.map((m,i)=><div key={i} className={`bubble ${m.role}`}>{m.content}</div>)}{busy&&<div className="bubble assistant">Pensando na melhor explicação...</div>}</div><div className="chat-controls"><label>Matéria<select value={subject} onChange={e=>setSubject(e.target.value)}>{subjects.map(s=><option key={s}>{s}</option>)}</select></label><label>Nível<select value={level} onChange={e=>setLevel(e.target.value)}><option>Adaptável ao meu nível escolar</option><option>Fácil</option><option>Médio</option><option>Difícil</option><option>Avançado, estilo vestibular</option></select></label><div className="composer"><input value={question} onChange={e=>setQuestion(e.target.value)} onKeyDown={e=>e.key==="Enter"&&askAI("chat")} placeholder="Digite sua dúvida..." /><button className="send" disabled={busy||!question.trim()} onClick={()=>askAI("chat")}>Enviar ↑</button></div><div className="quick-actions"><button onClick={()=>{setQuestion("Explique "+subject+" de um jeito simples, com exemplos.");}}>✧ Explicar matéria</button><button onClick={()=>{setTab("provas")}}>▤ Criar uma prova</button></div></div></section>}
        <footer>SUPREMESTUKD © 2026 · Aprender é evoluir.</footer>
      </section>
    </main>
  );
}

function Stat({icon,label,value}) { return <div className="stat"><span>{icon}</span><div><b>{value}</b><small>{label}</small></div></div>; }
function SubjectCard({name,icon,onClick}) { return <button className="subject-card" onClick={onClick}><span>{icon}</span><b>{name}</b><small>Ver conteúdo e resumo →</small></button>; }
